package AppiumSaucelab;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class TestCaseLogin {
    static AppiumDriver driver;
    public static AndroidTouchAction actions;

    @BeforeTest
    public static void main() throws MalformedURLException {
//        UiAutomator2Options options = new UiAutomator2Options();
//        options.setApp("C:\\Users\\Vanilla\\AppData\\Local\\Android\\Sdk\\platform-tools\\Android.SauceLabs.Mobile.Sample.app.2.7.1.apk");
//        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),options);



        DesiredCapabilities caps= new DesiredCapabilities();
        caps.setCapability("Platform name", "Android");
        caps.setCapability("appium:automationName", "Appium");
        caps.setCapability("appium:platformVersion", "12.0");
        caps.setCapability("appium:deviceName", "Android Emulator");
        caps.setCapability("appPackage", "com.swaglabsmobileapp");
        caps.setCapability("appActivity", "com.swaglabsmobileapp.MainActivity");
        caps.setCapability("app", System.getProperty("user.dir")+"/apps/Android.SauceLabs.Mobile.Sample.app.2.7.1.apk");
        driver = new AndroidDriver(new URL("http://localhost:4723/wd/hub"), caps);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


    }
    @Test
    public static void invalidUserName(){

        WebElement Username= driver.findElement(By.id("test-Username"));

        WebElement Password= driver.findElement(By.id("test-Password"));

        WebElement cl = driver.findElement(By.id("test-LOGIN"));

        Username.sendKeys("invalidusername");
        Password.sendKeys("12345678");
        cl.click();




        WebElement errTxt = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"test-Error message\"]/android.widget.TextView"));
        String actualErrTxt = errTxt.getAttribute("text");
        String expectedErrTxt = "Username and password do not match any user in this service.";

        Assert.assertEquals(actualErrTxt, expectedErrTxt);





    }




    @AfterTest
    public void tearDown(){


        if (null != driver) {
            driver.quit();
        }
    }

}
